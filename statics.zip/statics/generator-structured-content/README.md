# generator-structured-content-type

The generator for @bb-cli/bb-generate CLI.
Scaffolds Structured Content Items

1. Structured Content Type
    *The structured content type are used to create the structured content items that you can use with the Structured Content widget.*
2. 
## Install

Generator needs to be installed globally first:

```bash
npm install -g @backbase/generator-structured-content-type
```

## Usage

After that, run the following command:

```bash
bb-generate list
```

Generate Structured Content Widget:

```bash
bb-generate structured-content
```


Generate Structured Content Type:

```bash
bb-generate structured-content type
```

## Import to portal

The structured content widget and type that you can create using this generator should not be built so it requires to
 create, if you don't have it create it yet, a folder **prebuilt** in the **src** folder inside of your *collection* folder and generate 
 or move them in there
 
To package the collection run the following command:

```bash
bb-package [path-to-your-collection-folder]/src --prebuilt=[path-to-your-collection-folder]/src/prebuilt
```

To import the collection run the following command:

```bash
bb-import package.zip
```
