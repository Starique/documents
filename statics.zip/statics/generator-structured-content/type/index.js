const nameConventionRegex = /^structured-content-type-([^\-]+)-(.*?)?$/;
const extractPartFromName = (part) => (name) => name.replace(nameConventionRegex, part);
const namespace = extractPartFromName('$1');
const base = extractPartFromName('$2');
const fs = require('fs');
const jsonSchemaGenerator = require('generate-schema');

const prompts = (api, presets) => {
    const name = {
        type: 'input',
        name: 'name',
        message: 'Name',
        validate: value => {
            return (api.validate.isRequired(value, 'Name is required')
                    && value.match(nameConventionRegex));
        },
        filter: api.filter.trim,
        default: (answers) => api.filter.startCase(base(answers.name))
    };

    const json = {
        type: 'input',
        name: 'json',
        message: 'JSON Schema path',
        validate: value => api.validate.isRequired(value, 'JSON Schema path is required'),
        filter: api.filter.trim
    };

    return [
        name,
        json
    ];
};

const config = (api) => ({
    hooks: {
        preTransform: data => {
            if (!data.name.match(nameConventionRegex)) {
                console.log('Warning: name provided doesn\'t match naming convention for structured content types: ' +
                    'structured-content-type-<namespace>-<name>');
            }

            const baseName = base(data.name);
            const baseCamelCase = api.filter.camelCase(baseName);
            const baseCapitalize = api.filter.upperFirst(baseCamelCase);
            const json = JSON.parse(fs.readFileSync(data.json));
            const jsonSchema = JSON.stringify(jsonSchemaGenerator.json(baseCapitalize, json), null, 4);
            const jsonData = JSON.stringify(json, null, 4);

            return Object.assign(data, {
                base: baseName,
                baseCamelCase,
                baseCapitalize,
                jsonSchema
            });
        }
    }
});

module.exports = function (api, presets) {
    return api(
        prompts(api, presets),
        config(api)
    );
};
