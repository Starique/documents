# generator-structured-content-type

The generator for @bb-cli/bb-generate CLI.
Scaffolds Structured Content Type

The structured content type are used to create the structured content items that you can use with the Structured Content widget.

## Install

Generator needs to be installed globally first:

```bash
npm install -g @backbase/generator-structured-content-type
```

## Usage

After that, run the following command:

```bash
bb-generate list
```

Generate:

```bash
bb-generate structured-content type
```
