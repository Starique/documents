const nameConventionRegex = /^widget-([^\-]+)-(structured-content)?$/;
const extractPartFromName = (part) => (name) => name.replace(nameConventionRegex, part);
const namespace = extractPartFromName('$1');
const base = extractPartFromName('$2');
const getTemplateList = function (labels, values) {
    let templateList = '';
    if(labels.length !== values.length) {
        if(labels.length > values.length) {
            const itemsToAdd = labels.length - values.length;
            for(let index = 0; index < itemsToAdd; index++) {
                const templateName = '$(itemRoot)/templates/' + labels[values.length + 1].replace(/\s+/g, '-').toLowerCase();
                values.push(templateName);
            }
        } else {
            const itemsToAdd = values.length - labels.length;
            for(let index = 0; index < itemsToAdd; index++) {
                const name = values[labels.length + 1].replace('$(itemRoot)/templates/', '');
                let parts = name.split('-');
                parts = parts.map(function (part) {
                    return part.charAt(0).toUpperCase() + part.slice(1);
                });
                labels.push(parts.join(' '));
            }
        }
    }
    labels.forEach(function (label, index) {
        templateList += label + ',' + values[index];
    });
    return templateList;
};
const fs = require('fs');

const prompts = (api, presets) => {
    const name = {
        type: 'input',
        name: 'name',
        message: 'Name',
        validate: value => {
            return (api.validate.isRequired(value, 'Name is required')
                    && value.match(nameConventionRegex));
        },
        filter: api.filter.trim,
        default: (answers) => api.filter.startCase(base(answers.name))
    };

    const title = {
        type: 'input',
        name: 'title',
        message: 'Title',
        validate: value => api.validate.isRequired(value, 'Title is required'),
        filter: api.filter.trim,
        default: (answers) => (api.filter.startCase(namespace(answers.name)) + ' '  + api.filter.startCase(base(answers.name)))
    };

    const description = Object.assign({}, presets.description, {
        default: (answers) => (api.filter.startCase(namespace(answers.name)) + ' '  + api.filter.startCase(base(answers.name)))
    });

    const templateListLabels = {
        type: 'input',
        name: 'templateListLabels',
        message: 'Template List Labels',
        filter: api.filter.trim,
        default: (answers) => 'Basic Example'
    };

    const templateListValues = {
        type: 'input',
        name: 'templateListValues',
        message: 'Template List Values',
        filter: api.filter.trim,
        default: (answers) => '$(itemRoot)/templates/basic-example.html'
    };

    return [
        name,
        title,
        description,
        presets.version,
        templateListLabels,
        templateListValues
    ];
};

const config = (api) => ({
    hooks: {
        preTransform: data => {
            if (!data.name.match(nameConventionRegex)) {
                console.log('Warning: name provided doesn\'t match naming convention for structured content widget: ' +
                    'widget-<namespace>-structured-content');
            }
            const baseName = base(data.name);
            const baseCamelCase = api.filter.camelCase(baseName);
            const baseCapitalize = api.filter.upperFirst(baseCamelCase);
            const templateListLabels = data.templateListLabels.split(',');
            const templateListValues = data.templateListValues.split(',');
            const templateList = getTemplateList(templateListLabels, templateListValues);
            const namespaceName = namespace(data.name);
            return Object.assign(data, {
                base: baseName,
                baseCamelCase,
                baseCapitalize,
                templateList,
                namespaceName
            });
        }
    }
});

module.exports = function (api, presets) {
    return api(
        prompts(api, presets),
        config(api)
    );
};
